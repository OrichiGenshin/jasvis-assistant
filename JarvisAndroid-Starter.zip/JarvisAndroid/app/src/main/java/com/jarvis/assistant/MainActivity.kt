package com.jarvis.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private var armed = false
    private val wakePhrase = "hey jarvis"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
        }
        if (SpeechRecognizer.isRecognitionAvailable(this)) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        } else {
            status.text = "Speech recognition is unavailable on this device."
            listenButton.isEnabled = false
        }
    }

    private fun buildUi() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 40, 32, 40)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 34f
            gravity = Gravity.CENTER
            setTextColor(0xFF55C7FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI • VOICE CONSOLE"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(0xFF9BB7C9.toInt())
        }
        status = TextView(this).apply {
            text = "Tap START LISTENING, then say “Hey Jarvis”."
            textSize = 17f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 48, 0, 48)
        }
        listenButton = Button(this).apply {
            text = "START LISTENING"
            setOnClickListener {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    armed = true
                    status.text = "Listening… say “Hey Jarvis”."
                    listen()
                } else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 44)
            }
        }
        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                armed = false
                recognizer?.cancel()
                status.text = "Standby. Tap START LISTENING when ready."
            }
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(listenButton)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun listen() {
        if (!armed) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        try { recognizer?.startListening(intent) } catch (_: Exception) {
            status.text = "Could not start speech recognition. Check your device speech service."
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… say “Hey Jarvis”." }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onError(error: Int) {
            if (armed) status.postDelayed({ listen() }, 700)
        }
        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION).orEmpty()
            val heard = matches.firstOrNull()?.lowercase(Locale.ROOT).orEmpty()
            if (!armed) return
            if (heard.contains(wakePhrase)) {
                val command = heard.substringAfter(wakePhrase).trim()
                speak("Yes, sir. I'm listening.")
                if (command.isNotBlank()) handleCommand(command)
                else status.text = "JARVIS activated. Say a command."
            } else {
                status.text = "Waiting for “Hey Jarvis”…"
            }
            status.postDelayed({ listen() }, 900)
        }
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("open youtube") -> openApp("com.google.android.youtube", "YouTube")
            command.contains("open whatsapp") -> openApp("com.whatsapp", "WhatsApp")
            command.contains("open instagram") -> openApp("com.instagram.android", "Instagram")
            command.contains("open settings") -> startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("what time") || command == "time" -> {
                val now = java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date())
                speak("The time is $now.")
                status.text = "The time is $now"
            }
            command.startsWith("search ") -> {
                val q = command.removePrefix("search ")
                startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", q))
            }
            command.startsWith("text ") || command.startsWith("send message ") -> {
                val body = command.substringAfter("text ").takeIf { command.startsWith("text ") }
                    ?: command.substringAfter("send message ")
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = android.net.Uri.parse("smsto:")
                    putExtra("sms_body", body)
                }
                startActivity(intent) // User reviews recipient and sends manually.
                speak("I've prepared a message. Please review and send it.")
            }
            else -> {
                status.text = "Command heard: $command"
                speak("I heard $command. That command is not configured yet.")
            }
        }
    }

    private fun openApp(packageName: String, appName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch)
        else speak("$appName is not installed.")
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale.UK
            tts?.setSpeechRate(0.92f)
            speak("JARVIS systems online. Good day, sir.")
        }
    }

    override fun onDestroy() {
        armed = false
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }
}
